package Interfaces;

public interface Operaciones {

	public boolean vectorEspacio();
	public boolean vectorVacio();
	public boolean insertaDato(String nom);
	public int buscarDato(String buscar);
	public void ordenarDat();
	public String verDatos();
	

}
